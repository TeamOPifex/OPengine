'use strict';

angular.module('opengine', []);